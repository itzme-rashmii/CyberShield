---
name: Questions and Support
about: General topics. Questions and Support.
title: "[Questions and Support]"
labels: ''
assignees: ''

---

**Question**
Put your question on Maltrail's functionality.

**Support**
Put descrption of an issue you have with Maltrail settings up.
