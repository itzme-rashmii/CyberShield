#!/usr/bin/env python



import sys

if sys.version_info >= (3, 0):
    xrange = range
else:
    xrange = xrange
